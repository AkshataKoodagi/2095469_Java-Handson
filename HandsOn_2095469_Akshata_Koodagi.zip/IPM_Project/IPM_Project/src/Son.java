

public class Son extends Father {
	    public void methodB() {
	        System.out.println("method of Class Son1");
	    }
	}

